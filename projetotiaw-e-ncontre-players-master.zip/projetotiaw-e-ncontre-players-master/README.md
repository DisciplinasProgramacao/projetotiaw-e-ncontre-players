![Open in Codespaces](https://classroom.github.com/assets/open-in-codespaces-abfff4d4e15f9e1bd8274d9a39a0befe03a0632bb0f153d0ec72ff541cedbe34.svg)
# E-ncontre Players

Nosso projeto é uma plataforma que busca facilitar o encontro de players em jogos online com foco em jogos fps.

## Alunos integrantes da equipe

* Franklin Henrique de Araujo Silva  
* Marcos Cesar
* João Victor Alves
* Victor Tavora 
* João Guilherme 


## Professores responsáveis

* João Caram Santos de Oliveira
* Lucas Gabriel da Silva Felix

## Quadro de tarefas
https://github.com/orgs/DisciplinasProgramacao/projects/51/views/1

## Instruções para uso
Coloque aqui as instruções para acessar a página inicial do projeto (caminho completo do arquivo).
